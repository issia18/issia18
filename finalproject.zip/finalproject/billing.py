# ----------------------------------------------------------------
# Author:Christopher McAllister
# Date:
#
# This module calculates and displays billing information
# for students in the class registration system.  Student and
# class records are reviewed and tuition fees are calculated.
# -----------------------------------------------------------------
import datetime


def display_bill(s_id, s_in_state, c_rosters, c_hours):
    total_cost = 0
    total_credit = 0
    print('Tuition Summary')
    if s_in_state[s_id]:
        text = 'In-State Student'
        price = 225
    else:
        text = 'Out-of-State Student'
        price = 850
    print(f'Student: {s_id}, {text}')
    date = datetime.datetime.now().strftime('%b %d, %Y at %I:%M %p')
    print(date)
    print(f'{"Course"}{" "*2}{"Hours":>7}{" "*2}{"Cost":^9}')
    print(f'{"-"*6}{" "*2}{"-"*5:>7}{" "*2}{"-"*9}')
    for key, item in c_rosters.items():
        if s_id in item:
            amount = c_hours[key]*price
            total_cost += amount
            total_credit += c_hours[key]
            print(f'{key}{" " * 2}{c_hours[key]:>7}{" " * 2}{"$"}{amount:>8.2f}')
    print(f'{" " * 6}{" " * 2}{"-" * 7}{" " * 2}{"-" * 9}')
    print(f'{"Total"}{total_credit:>10}{" " * 2}{"$"}{total_cost:>8.2f}')
