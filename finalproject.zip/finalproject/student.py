# ----------------------------------------------------------------
# Author: Issagha Diallo
# Date:11/8/2023
#
# This module supports changes in the registered courses
# for students in the class registration system.  It allows
# students to add courses, drop courses and list courses they are
# registered for.
# -----------------------------------------------------------------

def list_courses(s_id, c_roster):
    # ------------------------------------------------------------
    # This function displays all the courses, indicates which ones
    # in which the student is enrolled, and counts the courses a
    # student has registered for. It has two parameters: s_id is the
    # ID of the student; c_roster is the list of class rosters.
    # This function has no return value.
    # -------------------------------------------------------------
    # define a counter
    count = 0
    print('Courses:')
    # Iterate through the items in the dictionary c_roster
    for key, item in c_roster.items():
        # Check if s_id is present in the current item
        if s_id in item:
            # If s_id is found in the item, print the key and indicate that the student is enrolled
            print(key, "(Enrolled)")
            count += 1  # Increment the count of enrolled courses
        else:
            print(key)  # If s_id is not found in the item, print only the key
        # Print the total number of courses the student is enrolled.
    print(f'Total courses enrolled: {count}')


def add_course(s_id, c_roster, c_max_size):
    # ------------------------------------------------------------
    # This function adds a student to a course.  It has three
    # parameters: s_id is the ID of the student to be added; c_roster is the
    # list of class rosters; c_max_size is the list of maximum class sizes.
    # This function asks user to enter the course he/she wants to add.
    # If the course is not offered, display error message and stop.
    # If student has already registered for this course, display
    # error message and stop.
    # If the course is full, display error message and stop.
    # If everything is okay, add student ID to the course’s
    # roster and display a message if there is no problem.  This
    # function has no return value.
    # -------------------------------------------------------------
    # Prompt the user to enter the course they want to add
    course_id = input('Enter the course you want to add:')
    while True:  # Infinite loop to handle course enrollment until true
        if course_id in c_roster:  # Check if the entered course exists in the roster
            if s_id not in c_roster[course_id]:  # Check if the student is not already enrolled in the course
                # Check the size of the class before adding the student
                list_size = len(c_roster[course_id])
                max_size = c_max_size[course_id]
                # If the class is not full, enroll the student and break out of the loop.
                if list_size < max_size:
                    c_roster[course_id].append(s_id)
                    print('Course added')
                    break
                else:
                    # If the class is full, prompt the user for another course or to quit
                    print('Course already full.\nDo you want to enrolled to  another course?')
                    course_id = input('enter the course you want to add: or 0 to quit. ')
                    if course_id == '0':
                        break

            else:
                # If the student is already enrolled in the course, display message and break out of the loop.
                print('You are already enrolled in that course.')
                break

        else:
            # If the entered course is not found, prompt the user to re-enter the course
            print('Course not found:')
            course_id = input('Renter the course you want to add:')


def drop_course(s_id, c_roster):
    # ------------------------------------------------------------
    # This function drops a student from a course.  It has two
    # parameters: s_id is the ID of the student to be dropped;
    # c_roster is the list of class rosters. This function asks
    # the user to enter the course he/she wants to drop.  If the course
    # is not offered, display error message and stop.  If the student
    # is not enrolled in that course, display error message and stop.
    # Remove student ID from the course’s roster and display a message
    # if there is no problem.  This function has no return value.
    # -------------------------------------------------------------
    # Prompt the user to enter the course they want to drop
    drop_course = input('Enter the course you want to drop:')
    # Check if the entered course exists in the roster
    if drop_course in c_roster:
        if s_id in c_roster[drop_course]:  # Check if the student is enrolled in the course
            c_roster[drop_course].remove(s_id)  # Remove the student from the course's list of enrolled students
            print("Course dropped")
        else:
            # If the student is not enrolled in the course, display a message  and return.
            print(" You are not enrolled in the course.")

    else:
        # If the entered course is not found, display a message and return.
        print(' Course not offered.')

